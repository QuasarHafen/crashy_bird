# 🐦 Crashy Bird – Dokumentation

**Entwickelt von:** AFG  
**Datum:** Tag 3 | 08:30 – 09:30 Uhr  
**Plattform:** Browser (HTML5)

---

## Spielbeschreibung

Crashy Bird ist ein Flappy-Bird-Spiel im Browser. Der Vogel fliegt durch Säulen, sammelt Münzen und darf die Säulen nicht berühren.

---

## Steuerung

| Aktion | Taste |
|--------|-------|
| Starten / Fliegen | Klick / Leertaste / Touch |
| Neustart | Restart-Button |

---

## Spielmechanik

- **Vogel** fällt durch Schwerkraft, Klick = nach oben fliegen
- **Säulen** kommen von rechts, Lücke ist zufällig
- **Münze** in der Lücke einsammeln = +1 Punkt
- **Highscore** wird pro Sitzung gespeichert
- Säule oder Boden berühren = Game Over

---

## Assets

| Grafik | Verwendung |
|--------|-----------|
| bird 1–3 | Vogel-Animation (3 Frames) |
| coin | Münze zwischen den Säulen |
| game_over | Game-Over-Anzeige |
| restart | Restart-Button |
| Hintergrund | Vollbild-Hintergrund |

---

## Starten

1. `crashy_bird.html` im Browser öffnen
2. Klicken oder Leertaste → Spiel startet

---

*© AFG – Crashy Bird*
