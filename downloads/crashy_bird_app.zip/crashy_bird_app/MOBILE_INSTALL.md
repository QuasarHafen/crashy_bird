# 📱 Crashy Bird – Mobile Installation

## Android (Chrome)
1. `crashy_bird.html` im **Chrome Browser** öffnen
2. Oben rechts auf **⋮ Menü** tippen
3. **"Zum Startbildschirm hinzufügen"** wählen
4. Bestätigen → App erscheint auf dem Homescreen
5. App starten → spielt wie eine echte App (Vollbild, offline)

## iOS (Safari)
1. `crashy_bird.html` im **Safari Browser** öffnen
2. Unten auf das **Teilen-Symbol ↑** tippen
3. **"Zum Home-Bildschirm"** wählen
4. Namen bestätigen → App erscheint auf dem Homescreen
5. App starten → spielt im Vollbild ohne Browser-Leiste

## Wichtig
- Die HTML-Datei muss lokal auf dem Gerät gespeichert sein
- Oder auf einem Webserver liegen (z.B. via USB / lokales WLAN)
- Kein App Store nötig!

---
*© AFG – Crashy Bird*
